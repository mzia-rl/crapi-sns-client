<?php

return [
    'sns' => [
        "access_key_id" =>  env('ACCESS_RFID'),
        "secret_access_key" =>  env('ACCESS_SECRET_RFID'),
        'subscriptions' => [],
        'watch_entities' => [
            
        ]
    ]
];
